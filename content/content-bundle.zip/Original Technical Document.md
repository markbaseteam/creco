
# CreCo
[Google Doc link](https://docs.google.com/document/d/1_USBsdjWynHcnUYVlB_ldZCKxq0mMKsuy_UtirReR0k/edit?usp=sharing)
Age of Extinction

### A Technical Document

CREco is a creature collection draft game with turn based combat. Players draft critters to form a team and then customize each critter to fit their plans to succeed.

ADD SECTION(S) ABOUT PHASES OF GAMEPLAY (ie. draft phase, combat phase, bracket scoring?)

### Critters

Critters will be unique in multiple ways. Critters will have one _Archetype_ and up to three _Attributes_. They will have possibly 3 Moves, with S tier critters having access to a unique 5th move called _Ascension_. They will also be allowed to have one _Mutation_ and one _Blessing_.

Each critter will have stats that are calculated using a variety of different methods: _[B](#_s53ri3h2l6r5)[ase Stats](#_s53ri3h2l6r5)_, [_Effort Values_](#_2a9eunog9nau)and [_Blessings_](#_x468vk1217rc). Critters have seven base stats which can be manipulated via stages. 6 of the 7 stats will have a counterpart [ev](#_2a9eunog9nau)system to further manipulate the stat. And finally there will be a [_Blessing_](#_x468vk1217rc)which increases a stat and decreases a stat.

## Tiers

## Archetypes

Archetypes will have little gameplay effect and are mostly designed to give an easy way for people to figure out the intended play style of the critter. Some archetypes will benefit from working with others of its type like beasts who give other beasts stag increases.

### Archetype List

|        |                          |                     |
|--------|--------------------------|---------------------|
| [[Dragon]] | Bruisers                 | Tanking abilities   |
| [[Dino]]   | Glass Cannons / Aggro    |                     |
| [[Insect]] | Swarm                    |                     |
| [[Beast]]  | Balance                  |                     |
| [[Undead]] | Bloodletting             |                     |
| [[Earth]]  | Stall / Creature control |                     |
| [[Xeno]]   | Mimicry                  | Anti-Meta creatures |
| [[Sea]]    | Battlefield Control      |                     |


## Attributes

Attributes are what make creatures unique. Attributes are preset gameplay interactions set up for a critter.

### Example Attributes
|                |                                                    |
|----------------|----------------------------------------------------|
| Aqua           | Grants main Stat Increase during Rain              |
|                |                                                    |
| Mineral/Scales | Grants resistance to elemental; weak to industrial |

## Stats

Base stats are innate and cannot be changed, except by [_EffortValues_](#_2a9eunog9nau)

_Add something about how to calculate BST_

S tiers can have BST totaling X

A tiers can have BST value

### Base Stats

| Health | Total health of the creature |
| --- | --- |
| Attack | Physical attacking calculating |
| Defense | Physical Defense calculator |
| Special Attack |
 |
| Special Defense |
 |
| Speed | How fast your creature is |
| Crit Chance | How fast your |

## Effort Values

EVs give players the ability to finetune creatures base stats to customize how your creature plays

## Blessings (items)

Blessings are player chosen upgrades that allow critters to become stronger in unique ways! Some blessings will strengthen attacks, bolster defenses or even regenerate health. Some Blessings can be consumed when a certain condition is met. Finally Blessings can be removed or swapped by certain moves.

### Example Blessings

|
 |
 |
| --- | --- |
|
 |
 |
|
 |
 |

##


## Mutations (Natures)

Mutations are a stat manipulation system. Every critter will have up to one boon that can boost one stat and a corresponding bane to hinder another.

### Example Mutations

| Neutral | No change |
| --- | --- |
| Brave | Attack Bonus / speed reduction |
| Timid | Speed Bonus / Attack reduction |

##


## Ascension

Each S tier creature will have the ability to Ascend in some form. Once Ascended the creature will gain predefined

- Multiple ways to trigger
  - Passive
  - Move based
  - Time based attribute
- Kinda a comeback mechanic
- Tool to make the s tiers just a little bit better
- Once a creature ascend it will be ascended for the rest of the match

### Draft

Players will draft a bench of 9 to form teams of 6 creatures to battle another bench of 9 forming a team of 6

Draft 1S tier 2A + 3B + 3C

Draft will be snake draft

## Practice Draft

NOT ON alpha

## Regular Draft

Regular draft will consist of a snake draft picking a total bench of 9 creatures

###


## Creature Classes

Some description here

###
 Classes

| Sweeper |
 |
| --- | --- |
| Demolisher |
 |
| Orchestrator |
 |
| Suppressor |
 |
| Warden |
 |
| Meddler |
 |
| Ballanced |
 |
| Joker |
 |

##


### Combat

Once a bench has been built, you will pick six creatures to form a team. Y

Normal combat will consist of teams of six, fighting 1v1 until one team runs out of critters.

- Stamina system
- Back and forth based on speed
- Actions each turn
  - Use a move
  - Hard switch a creature
  - Recover stamina

## Stamina

Stamina controls how you can play on the field. Each move will have a defined stamica cost.

- Passively ganed
- Need to watch for infinite loop scenarios during playtest
- Perhaps heal type moves will prevent passive stamina regeneration

## Moves

Each creature other than S tier will have x moves

### Example Moves

| -- |
 |
| --- | --- |
| -- |
 |
| -- |
 |
| -- |
 |
| -- |
 |
| -- |
 |
| -- |
 |

[(See List of moves in linked documents)](#_48i9bdbacadw)

## Status Conditions

Some Moves or Attributes will have the ability to apply a Status Condition. If this creature is afflicted with the condition, certain effects will be applied to the creature for the duration of the condition. Conditions can be cleared with a held mutation or certain recovery type moves or running out the condition timer. Some Creatures will be immune to certain conditions based on their attributes

### Status Conditions Defined

| Sleep | Sleep will disable your creature until hit by a attacking move or two turns pass |
| --- | --- |
| Frozen | Lose a turn based on counters ending in a flinch |
| Poison | Overtime health penalty |
| Demoralize | Overtime penalty to crit chance calculator |
| Exaustion | Overtime penalty to players stamina counter |

##


## Field mechanics

The Playfield has three different mechanics that players can interact with.

| [Weather](#_56y29ste5zxv) | [Field Debuff](#_i0v6o5p54t7) | [Terrain](#_st7xrkhadw6l) |
| --- | --- | --- |

Each Mechanic is designed to manipulate a certain portion of gameplay.

### **Weather**

Weather is the sky and what's happening there. These will increase specific stats for different [attributes](#_l8ldbkany7v4). There may only be one weather in place at a time.

#### Rain

will increase the main stat of _aqua_ attributes critters, while ocean terrain will boost the power of _aqua_ attributed moves. [Battle pheromones](#_qgmpfzlrf3tf)' atmospheric effect will cause aqua critters to only declare attacking moves.

- Fire will be weaker
- Synergises with bog

#### Sandstorm

- Synergises with x

#### Sunny Day

- Synergises with x

#### Snow

- Synergises with x

### **Field Debuff**

Field Debuff is the air around you; what you breathe in, the rock sitting beside you, or anything that correlates directly to what's around you. Field Debuff will affect critters in unique ways depending on which atmospheric effect is in place. Multiple field debuffs can be in place at once. So stealth rocks and battle pheromones can both be in place.

##### Example Hazards

|
 |
 |
| --- | --- |
|
 |
 |
| -- |
 |
| -- |
 |
| -- |
 |
| -- |
 |
| -- |
 |

##


#### Entry Hazards

[_Entry hazards_](#_kfuqjpyhtzt9) reside within the Field Debuff, but only on one side.

##### Example Hazards

| Caltrops | (discript in db) |
| --- | --- |
| Dry Ice Myst | (discript in db) |
| Awful site | (discript in db) |
| Lightning Storm | (discript in db) |
| -- |
 |
| -- |
 |
| -- |
 |

##


#### Battle Pheromones

ADD CONTENT

#### Dreamlands

ADD CONTENT

#### Prehistoric Fog

ADD CONTENT

### **Terrain**

Terrain is the environment around you and allows certain critters to move more naturally if in their natural habitat. Terrains boost the specific power of moves with specific attributes. There may only be one terrain in place at a time.

#### Prehistoric Jungle

- Synergises with x

#### Deep Sea Lab

- Synergises with x

#### Mountainous Factory

- Synergises with x

#### Boglands

- Synergises with rain

### Linked Documents

[Creature Base List](https://docs.google.com/spreadsheets/d/1OvckaWi5KNYHZBhqzSvKJva4a-J5_aJzILvHDPsklJc/edit?usp=sharing)

[Description Database](https://docs.google.com/spreadsheets/d/1erax5L2B7IWEIBDkFwkEmvq1CWBnZZKIrFTr_K1LIdQ/edit?usp=sharing)

### MSC ARTWORK

![](RackMultipart20230419-1-qn915r_html_5e39d1698235e303.png)

![](RackMultipart20230419-1-qn915r_html_14c168ec84ef4226.png)

![](RackMultipart20230419-1-qn915r_html_288d6ef2f38bd1d3.png)

I ![](RackMultipart20230419-1-qn915r_html_ccf65da6a99db3bf.png)

![](RackMultipart20230419-1-qn915r_html_56d700c0cd096348.png)
